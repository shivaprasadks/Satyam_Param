package com.think.survey2016.model;

/**
 * Created by Super on 03-12-2016.
 */

public class QuestionModel {
    public String qimg;
    public String qid;
    public String question;
    public String total;
    public String op1;
    public String op2;
}
